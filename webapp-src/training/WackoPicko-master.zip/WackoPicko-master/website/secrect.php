<?php

echo "This will be vulnerable!";

?>