<?php

$username = "wackopicko";
$pass = "webvuln!@#";
$database = "wackopicko";

require_once("database.php");
$db = new DB("localhost", $username, $pass, $database);


?>