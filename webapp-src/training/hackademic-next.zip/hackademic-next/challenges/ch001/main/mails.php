<?php 
/** 
 *    ----------------------------------------------------------------
 *    OWASP Hackademic Challenges Project
 *    ----------------------------------------------------------------
 *    Copyright (C) 2010-2011 
 *   	  Andreas Venieris [venieris@owasp.gr]
 *   	  Anastasios Stasinopoulos [anast@owasp.gr]
 *    ----------------------------------------------------------------
 */
?>
<html>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1253">
<meta http-equiv="Content-Language" content="el">
<meta name="ProgId" content="FrontPage.Editor.Document">

<font size="6"><span lang="en-us">Special Clients' Mailbox</font><b><font size="6"></font></b><body>
<img border="1" src="./secret_area_/mails.gif" width="21" height="20"></body><hr><p><body>
</p>
<p>We currently have 5 special clients, who will help us in achieving our goals.<br>
<br>
This list will soon grow through the new programme for the expansion of our corporate goals.<br>
<br>
It is estimated that we will have reached 20 special customers within the next 6 months.<br>
</p>
<p><span lang="el"><a href="main.htm">Home</a></span></p>
</body>

</html>
