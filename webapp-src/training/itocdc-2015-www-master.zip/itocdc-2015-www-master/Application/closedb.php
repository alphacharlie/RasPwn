<?php
$db = null;
?>
