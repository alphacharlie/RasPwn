<?php
  // security header settings
  header("X-XSS-Protection: 0");
?> 
