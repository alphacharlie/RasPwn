<iframe
	id="id-iframe"
	width="100%" 
	height="600px" 
	src="./phpmyadmin/index.php" 
	style="margin-left:auto; margin-right:auto;border: 0px;"
	>
</iframe>