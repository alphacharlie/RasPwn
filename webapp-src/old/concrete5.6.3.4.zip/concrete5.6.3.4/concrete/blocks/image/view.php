<?php
defined('C5_EXECUTE') or die("Access Denied.");
echo($controller->getContentAndGenerate());
?>