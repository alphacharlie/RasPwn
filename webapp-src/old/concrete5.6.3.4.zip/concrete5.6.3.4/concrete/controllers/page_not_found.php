<?php

defined('C5_EXECUTE') or die("Access Denied.");
class PageNotFoundController extends Concrete5_Controller_PageNotFound {
	
	
}