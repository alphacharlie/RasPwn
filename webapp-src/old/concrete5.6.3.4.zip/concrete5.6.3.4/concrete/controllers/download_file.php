<?php

defined('C5_EXECUTE') or die("Access Denied.");
class DownloadFileController extends Concrete5_Controller_DownloadFile {


	
}
