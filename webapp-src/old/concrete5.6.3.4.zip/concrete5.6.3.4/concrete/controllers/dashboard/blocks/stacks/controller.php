<?php
defined('C5_EXECUTE') or die("Access Denied.");
class DashboardBlocksStacksController extends Concrete5_Controller_Dashboard_Blocks_Stacks {


	
}