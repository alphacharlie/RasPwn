<?php
defined('C5_EXECUTE') or die("Access Denied.");
class DashboardBlocksTypesController extends Concrete5_Controller_Dashboard_Blocks_Types {

	
}