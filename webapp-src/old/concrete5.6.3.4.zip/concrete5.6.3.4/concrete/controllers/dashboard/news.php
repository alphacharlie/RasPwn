<?php

defined('C5_EXECUTE') or die("Access Denied.");
class DashboardNewsController extends Concrete5_Controller_Dashboard_News {


}