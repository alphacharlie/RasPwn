<?php defined('C5_EXECUTE') or die('Access Denied');

class DashboardSystemAttributesTypesController extends Concrete5_Controller_Dashboard_System_Attributes_Types {}