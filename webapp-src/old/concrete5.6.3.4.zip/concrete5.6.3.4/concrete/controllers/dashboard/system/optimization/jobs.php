<?php defined('C5_EXECUTE') or die("Access Denied.");

class DashboardSystemOptimizationJobsController extends Concrete5_Controller_Dashboard_System_Optimization_Jobs {

	
}