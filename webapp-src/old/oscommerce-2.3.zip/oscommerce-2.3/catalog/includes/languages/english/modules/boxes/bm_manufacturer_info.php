<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_MANUFACTURER_INFO_TITLE', 'Manufacturer Info');
  define('MODULE_BOXES_MANUFACTURER_INFO_DESCRIPTION', 'Show manufacturer information on the product information page');
  define('MODULE_BOXES_MANUFACTURER_INFO_BOX_TITLE', 'Manufacturer Info');
  define('MODULE_BOXES_MANUFACTURER_INFO_BOX_HOMEPAGE', '%s Homepage');
  define('MODULE_BOXES_MANUFACTURER_INFO_BOX_OTHER_PRODUCTS', 'Other products');
?>
