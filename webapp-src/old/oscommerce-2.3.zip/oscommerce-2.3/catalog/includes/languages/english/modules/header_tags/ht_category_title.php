<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_CATEGORY_TITLE_TITLE', 'Category Title');
  define('MODULE_HEADER_TAGS_CATEGORY_TITLE_DESCRIPTION', 'Add the title of the current category to the page title');
?>
