<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_PRODUCT_TITLE_TITLE', 'Product Title');
  define('MODULE_HEADER_TAGS_PRODUCT_TITLE_DESCRIPTION', 'Add the title of the current product to the page title');
?>
