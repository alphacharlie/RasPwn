<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_SECURITY_CHECKS_TITLE', 'Security Checks');
define('MODULE_ADMIN_DASHBOARD_SECURITY_CHECKS_DESCRIPTION', 'Run security checks');
define('MODULE_ADMIN_DASHBOARD_SECURITY_CHECKS_SUCCESS', 'This is a properly configured installation of osCommerce Online Merchant!');
?>
